<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

                    </section>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->

            <!-- Main Footer -->
            <footer class="main-footer">
                <!-- To the right -->
                <div class="pull-right hidden-xs">
                    <a href="<?php echo base_url("pages/syarat-ketentuan"); ?>">Syarat & Ketentuan</a> . 
                    <a href="<?php echo site_url("pages/kebijakan-privasi"); ?>">Kebijakan Privasi</a>
                </div>
                <!-- Default to the left -->
                <strong>Copyright &copy; 2017-2018 <a href="#">MUTAN COMMUNITY</a>.</strong> All rights reserved.
            </footer>

        </div>
        <!-- ./wrapper -->
    </body>
</html>

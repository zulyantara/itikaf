<div class="row">
    <div class="col-md-12">
        <div class="panel panel-success tara-no-radius">
            <div class="panel-heading tara-no-radius panel-tara">
                <h3 class="panel-title">Form Pendaftaran I'tikaf</h3>
            </div>
            <div class="panel-body">

                <div class="jumbotron">
                    <h1>Pendaftaran Berhasil!</h1>
                    <p>Informasi <?php echo ucwords($peserta_nama); ?> sedang kami proses.
                    <p>Untuk selanjutnya, silahkan kontak Admin di nomor <strong>WhatsApp 0877-7070-0207.</strong>
                    <p><a class="btn btn-primary btn-lg" href="<?php echo site_url("cpanels"); ?>" role="button">Login</a></p>
                </div>

            </div>
        </div>
    </div>
</div>
